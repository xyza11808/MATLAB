Abf2Tmp-
converts abf files to temporary files for loading with matlab.
