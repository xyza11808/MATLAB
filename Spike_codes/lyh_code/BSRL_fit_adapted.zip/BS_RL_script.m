%%
% filename = 'rs4';
% load('rs4_20200924_Afc_used22');
%%
lb = [0,1e-5,0,0];
ub = [1,10,1,1];
ntime = 10;
BlockSectionInfo = Bev2blockinfoFun(behavResults);
RevFreqs = BlockSectionInfo.BlockFreqTypes(logical(BlockSectionInfo.IsFreq_asReverse));
if exist('SessionResults','var')
   [Octave_used,left_choice_used,inds_correct_used,inds_use,inds_rev] = BehInput(SessionResults,RevFreqs);
elseif exist('behavResults','var')
    [Octave_used,left_choice_used,inds_correct_used,inds_use,inds_rev] = BehInput(behavResults,RevFreqs);
end
        
        
NLLfun = @(x,Octave_used,left_choice_used,inds_correct_used) NLL_MB_RL_function_v4(x(1),x(2),x(3),x(4),Octave_used,left_choice_used,inds_correct_used);



fitfun = @(para) NLLfun(para,Octave_used,left_choice_used,inds_correct_used);

for n = 1:ntime
    tic
    xx =lb+rand(1,numel(ub)).*(ub-lb); %seed random starting point
    options = optimset('Algorithm','sqp','MaxFunEvals',3000,'MaxIter',1000,'FunValCheck','on');
    nonlcon = [];

    [bestx(n,:) negll(n)]=fmincon(fitfun,xx,[],[],[],[],lb,ub);
    toc
end
numbest = find(negll == min(negll));

parameters = bestx(numbest(1),:);
theta_fit = parameters(1);
beta_fit = parameters(2);
alpha_fit = parameters(3);
P_bound_low_init = parameters(4);
%%
[P_choiceLeft,nll,delta,V_R,V_L,P_bound_low,P_bound_high]= MB_RL_function_v4(theta_fit,beta_fit,alpha_fit,P_bound_low_init,Octave_used,left_choice_used,inds_correct_used);
% figure for behavior
figure
plot(smooth(P_choiceLeft(inds_rev(inds_use)),5),'color',[.6 0 .8],'linewidth',2);
hold on
plot(smooth(double(left_choice_used(inds_rev(inds_use))),5),'k','linewidth',2);
xlabel('#Trial','FontSize',10);
ylabel('Leftward choice','FontSize',10);
set(gca,'FontSize',10);
%%
filename_1 = [filename '_BSRL_ReversingTrials'];
saveas(gcf,[filename_1  '.png']);
saveas(gcf,[filename_1  '.fig']);
saveas(gcf,[filename_1  '.eps']);
close all


%
filename_2 = [filename '_BSRL.mat'];
save(filename_2,'theta_fit','beta_fit','alpha_fit','P_bound_low_init','nll','inds_correct_used','P_choiceLeft','delta','V_L','V_R','P_bound_low','P_bound_high');
%%
% load('F:\20200924\rs4\afc\im_data_reg_cpu\result_save_new\rs4_BSRL.mat')
 %
figure;plot (delta,'.');

xlabel('#Trial','FontSize',15);
ylabel('Prediction error(delta)','FontSize',15);
set(gca,'FontSize',15);
box off
set(gca,'tickdir','out');
%%
